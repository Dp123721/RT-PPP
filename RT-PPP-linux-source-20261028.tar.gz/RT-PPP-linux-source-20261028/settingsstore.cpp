#include "settingsstore.h"

#include <QJsonDocument>
#include <QSettings>

SettingsStore::SettingsStore(const QString& filePath)
    : _filePath(filePath) {
}

QJsonArray SettingsStore::loadStreams() const {
    QSettings s(_filePath, QSettings::IniFormat);
    const QByteArray jsonText = s.value("streams/list_json").toByteArray();
    const QJsonDocument doc = QJsonDocument::fromJson(jsonText);
    if (doc.isArray()) {
        return doc.array();
    }
    return QJsonArray();
}

void SettingsStore::saveStreams(const QJsonArray& streams) {
    QSettings s(_filePath, QSettings::IniFormat);
    s.setValue("streams/list_json", QString::fromUtf8(QJsonDocument(streams).toJson(QJsonDocument::Compact)));
    s.remove("streams/ntrip_json");
    s.remove("streams/tcp_json");
    s.remove("streams/mqtt_json");
}

QJsonArray SettingsStore::loadCasters() const {
    QSettings s(_filePath, QSettings::IniFormat);
    const QByteArray jsonText = s.value("casters/list_json").toByteArray();
    const QJsonDocument doc = QJsonDocument::fromJson(jsonText);
    if (doc.isArray()) {
        return doc.array();
    }
    return QJsonArray();
}

void SettingsStore::saveCasters(const QJsonArray& casters) {
    QSettings s(_filePath, QSettings::IniFormat);
    s.setValue("casters/list_json", QString::fromUtf8(QJsonDocument(casters).toJson(QJsonDocument::Compact)));
}
