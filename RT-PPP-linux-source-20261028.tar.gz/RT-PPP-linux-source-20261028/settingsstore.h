#ifndef SETTINGSSTORE_H
#define SETTINGSSTORE_H

#include <QJsonArray>
#include <QString>

class SettingsStore
{
public:
    explicit SettingsStore(const QString& filePath = "rtppp_settings.ini");

    QJsonArray loadStreams() const;
    void saveStreams(const QJsonArray& streams);
    QJsonArray loadCasters() const;
    void saveCasters(const QJsonArray& casters);
    QString filePath() const { return _filePath; }
    void setFilePath(const QString& filePath) { _filePath = filePath; }

private:
    QString _filePath;
};

#endif // SETTINGSSTORE_H
