#include "outputworker.h"
#include "gnss_utils.h"

#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTemporaryDir>

#include <array>
#include <iostream>

namespace {

bool check(bool condition, const char* message) {
    if (!condition) {
        std::cerr << "outputworker smoke test failed: " << message << "\n";
    }
    return condition;
}

} // namespace

int main(int argc, char* argv[]) {
    QCoreApplication app(argc, argv);
    QTemporaryDir temporary;
    if (!check(temporary.isValid(), "temporary directory creation failed")) return 1;

    const QDateTime utc(QDate(2026, 8, 25), QTime(11, 59, 57), Qt::UTC);
    const GnssUtils::GpsTime gpsTime = GnssUtils::currentGpsTime(utc);

    OutputWorker::Config config;
    config.sp3Enabled = true;
    config.sp3Directory = QDir(temporary.path()).filePath("sp3");
    config.sp3SampleSec = 1;
    config.rinexEnabled = true;
    config.rinexDirectory = QDir(temporary.path()).filePath("rinex");
    config.pppJsonEnabled = true;
    config.pppJsonDirectory = QDir(temporary.path()).filePath("ppp_json");
    config.pppJsonReorderBufferMs = 0;
    config.pppJsonFlushIntervalMs = 0;
    config.ztdDirectory = QDir(temporary.path()).filePath("ztd");
    config.logFilePath = QDir(temporary.path()).filePath("runtime.log");
    config.telemetryDirectory = QDir(temporary.path()).filePath("telemetry");
    config.arLogFilePath = QDir(temporary.path()).filePath("pppar.log");

    PppSolution solution;
    solution.valid = true;
    solution.utc = utc;
    solution.gpsWeek = gpsTime.week;
    solution.gpsSow = gpsTime.sow;
    solution.xyz[0] = 1111111.0;
    solution.xyz[1] = 2222222.0;
    solution.xyz[2] = 3333333.0;
    solution.ztd = 2.345;
    solution.ztdStdev = 0.012;
    solution.trp = 0.123;
    solution.numSat = 12;
    solution.hDop = 1.2;
    solution.arLogLines << QStringLiteral("AR smoke line");

    OutputWorker worker;
    worker.configure(config);
    worker.enqueueLog(QStringLiteral("runtime smoke line"));
    worker.enqueueArLog(solution);
    worker.enqueueZtd(QStringLiteral("OBS"), QStringLiteral("BJFS"), solution);
    worker.enqueuePppJson(QStringLiteral("BJFS"), solution,
                          {solution.xyz[0], solution.xyz[1], solution.xyz[2]});
    worker.enqueueTelemetryReception(QStringLiteral("OBS"), utc, QStringLiteral("MSM"),
                                      1077, QLatin1Char('G'), QStringLiteral("received"),
                                      QString(), QStringLiteral("smoke"));
    worker.enqueueSp3(gpsTime.week, gpsTime.sow, QStringLiteral("G01"),
                      {15600000.0, 20100000.0, 21700000.0}, 1.0e-4,
                      {0.0, 0.0, 0.0}, 0.0);
    QMap<QString, QMap<QString, double>> observations;
    observations[QStringLiteral("G01")][QStringLiteral("C1C")] = 22000000.0;
    observations[QStringLiteral("G01")][QStringLiteral("L1C")] = 110000000.0;
    worker.enqueueRinex(gpsTime.week, gpsTime.sow, observations);
    worker.finalizePppJson();

    const QString day = utc.toString(QStringLiteral("yyyyMMdd"));
    if (!check(QFile::exists(config.logFilePath), "runtime log was not written")) return 1;
    if (!check(QFile::exists(config.arLogFilePath), "AR log was not written")) return 1;
    const QString ztdPath = QDir(config.ztdDirectory).filePath("ztd_BJFS.txt");
    if (!check(QFile::exists(ztdPath),
               "ZTD file was not written")) return 1;
    QFile ztdFile(ztdPath);
    if (!check(ztdFile.open(QIODevice::ReadOnly), "ZTD file cannot be opened")) return 1;
    const QByteArray ztd = ztdFile.readAll();
    if (!check(ztd.contains(QByteArrayLiteral("GPS ISO8601")) &&
                   ztd.contains(QByteArrayLiteral("2026-08-25T12:00:15.000Z")),
               "ZTD output does not use the GPS calendar epoch")) return 1;
    QFile arFile(config.arLogFilePath);
    if (!check(arFile.open(QIODevice::ReadOnly), "AR log cannot be opened")) return 1;
    if (!check(arFile.readAll().startsWith(QByteArrayLiteral("2026-08-25 12:00:15.000")),
               "AR log does not use the GPS calendar epoch")) return 1;
    if (!check(QFile::exists(QDir(config.pppJsonDirectory)
                                 .filePath("BJFS/ppp_BJFS_20260825.json")),
               "PPP JSON file was not written")) return 1;
    const QString pppJsonPath = QDir(config.pppJsonDirectory)
                                    .filePath("BJFS/ppp_BJFS_20260825.json");
    QFile pppJsonFile(pppJsonPath);
    if (!check(pppJsonFile.open(QIODevice::ReadOnly), "PPP JSON file cannot be opened")) return 1;
    const QByteArray pppJson = pppJsonFile.readAll();
    if (!check(pppJson.endsWith(QByteArrayLiteral("]}\n")), "PPP JSON was not finalized")) return 1;
    if (!check(!QJsonDocument::fromJson(pppJson).isNull(), "PPP JSON is not valid after finalization")) return 1;
    const QJsonObject pppRoot = QJsonDocument::fromJson(pppJson).object();
    if (!check(pppRoot.value(QStringLiteral("meta")).toObject()
                   .value(QStringLiteral("timeBase")).toObject()
                   .value(QStringLiteral("system")).toString() == QLatin1String("GPS"),
               "PPP JSON is not labelled as GPS time")) return 1;
    if (!check(QFile::exists(QDir(config.telemetryDirectory)
                                 .filePath(QString("reception_%1.csv").arg(day))),
               "telemetry file was not written")) return 1;
    if (!check(QFile::exists(QDir(config.sp3Directory)
                                 .filePath(QString("rtppp_%1.sp3").arg(day))),
               "SP3 file was not written")) return 1;
    if (!check(QFile::exists(QDir(config.sp3Directory)
                                 .filePath(QString("rtppp_%1.clk").arg(day))),
               "CLK file was not written")) return 1;
    if (!check(!QDir(config.rinexDirectory)
                    .entryList(QStringList() << QStringLiteral("*.rnx"), QDir::Files)
                    .isEmpty(),
               "RINEX file was not written")) return 1;

    worker.shutdown();

    std::cout << "outputworker smoke test passed\n";
    return 0;
}
