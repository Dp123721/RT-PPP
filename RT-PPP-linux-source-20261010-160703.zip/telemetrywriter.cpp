#include "telemetrywriter.h"

#include "gnss_signals.h"
#include "gnss_utils.h"

#include <cmath>
#include <limits>
#include <QDir>
#include <QFileInfo>
#include <QTimer>

namespace {

QStringList msmHeader() {
    return {"source_id", "received_utc", "epoch_utc", "station_id", "system",
            "message_type", "msm_subtype", "multiple_message", "iods",
            "clock_steering_indicator", "external_clock_indicator", "smoothing_indicator",
            "smoothing_interval", "satellite", "sat_id", "signal_id", "signal",
            "cell_active", "has_fine_pseudorange", "fine_pseudorange_ms",
            "has_fine_phase_range", "fine_phase_range_ms", "has_lock_time",
            "lock_time_indicator", "lock_time_seconds", "has_half_cycle",
            "half_cycle_ambiguity", "has_cnr", "cnr_dbhz", "has_fine_phase_rate",
            "fine_phase_rate_mps", "azimuth_deg", "elevation_deg"};
}

QStringList ssrHeader() {
    return {"source_id", "received_utc", "epoch_utc", "message_type", "kind", "system",
            "update_interval_index", "update_interval_seconds", "multiple_message", "ssr_iod",
            "provider_id", "solution_id", "sat_ref_datum", "satellite", "satellite_iod", "toe",
            "has_orbit", "delta_radial_m", "delta_along_m", "delta_cross_m",
            "has_clock", "delta_clock_m", "has_high_rate_clock", "high_rate_clock_m",
            "code_bias_count", "phase_bias_count", "age_seconds", "adopted", "reason"};
}

QStringList receptionHeader() {
    return {"source_id", "received_utc", "message_family", "message_type", "system",
            "status", "reason", "detail"};
}

QStringList pppResidualHeader() {
    return {"source_id", "epoch_utc", "satellite", "signal",
            "observation_type", "prefit_m", "postfit_m", "sigma_m",
            "elevation_deg", "adopted", "reason"};
}

QStringList headerFor(const QString& family) {
    if (family == "msm") return msmHeader();
    if (family == "ssr") return ssrHeader();
    if (family == "ppp_residual") return pppResidualHeader();
    return receptionHeader();
}

} // namespace

TelemetryWriter::TelemetryWriter(QObject* parent)
    : QObject(parent), _flushTimer(new QTimer(this)) {
    _flushTimer->setInterval(500);
    connect(_flushTimer, &QTimer::timeout, this, [this]() { flush(); });
}

TelemetryWriter::~TelemetryWriter() {
    close();
}

void TelemetryWriter::setOutputDirectory(const QString& directory) {
    const QString normalized = directory.trimmed().isEmpty()
        ? QString() : QDir::cleanPath(directory.trimmed());
    if (_directory == normalized) {
        if (isEnabled() && !_flushTimer->isActive()) {
            _flushTimer->start();
        }
        return;
    }

    close();
    _directory = normalized;
    if (isEnabled()) {
        _flushTimer->start();
    }
}

bool TelemetryWriter::isEnabled() const {
    return !_directory.trimmed().isEmpty();
}

void TelemetryWriter::writeMsm(const QString& sourceId,
                               const QDateTime& receivedUtc,
                               const QDateTime& epochUtc,
                               const RtcmMsmMessage& message,
                               const QMap<QString, QPair<double, double>>& skyBySatellite) {
    if (!isEnabled()) return;
    for (const RtcmMsmCellData& cell : message.cells) {
        RtcmSatId satellite;
        satellite.system = message.system;
        satellite.number = cell.satId;
        const QString satelliteId = satelliteText(satellite);
        const QPair<double, double> sky = skyBySatellite.value(satelliteId);
        const bool hasSky = skyBySatellite.contains(satelliteId);
        const QString signal = msmSignalToRinexType2ch(message.system, cell.signalId, message.signalIds);
        appendRow("msm", receivedUtc,
                  {sourceId, utcText(receivedUtc), utcText(epochUtc), QString::number(message.stationId),
                   QString(message.system), QString::number(message.messageType),
                   QString::number(message.msmSubtype), boolText(message.multipleMessage),
                   QString::number(message.iods), QString::number(message.clockSteeringIndicator),
                   QString::number(message.externalClockIndicator), boolText(message.smoothingIndicator),
                   QString::number(message.smoothingInterval), satelliteId, QString::number(cell.satId),
                   QString::number(cell.signalId), signal, boolText(cell.active),
                   boolText(cell.hasFinePseudorange), cell.hasFinePseudorange ? number(cell.finePseudorangeMillis) : QString(),
                   boolText(cell.hasFinePhaseRange), cell.hasFinePhaseRange ? number(cell.finePhaseRangeMillis) : QString(),
                   boolText(cell.hasLockTime), cell.hasLockTime ? QString::number(cell.lockTimeIndicator) : QString(),
                   cell.hasLockTime ? number(cell.lockTimeSec) : QString(), boolText(cell.hasHalfCycle),
                   cell.hasHalfCycle ? QString::number(cell.halfCycleAmbiguity) : QString(), boolText(cell.hasCnr),
                   cell.hasCnr ? number(cell.cnrDbHz) : QString(), boolText(cell.hasFinePhaseRate),
                   cell.hasFinePhaseRate ? number(cell.finePhaseRateMps) : QString(),
                   hasSky ? number(sky.first) : QString(), hasSky ? number(sky.second) : QString()});
    }
}

void TelemetryWriter::writeSsr(const QString& sourceId,
                               const QDateTime& receivedUtc,
                               const QDateTime& epochUtc,
                               const RtcmSsrMessage& message,
                               const RtcmSsrSatelliteData& satellite,
                               bool adopted,
                               const QString& reason) {
    if (!isEnabled()) return;
    const double age = epochUtc.isValid() && receivedUtc.isValid()
        ? epochUtc.msecsTo(receivedUtc) / 1000.0 : std::numeric_limits<double>::quiet_NaN();
    appendRow("ssr", receivedUtc,
              {sourceId, utcText(receivedUtc), utcText(epochUtc), QString::number(message.messageType),
               ssrKindText(message.kind), QString(message.system), QString::number(message.updateIntervalIndex),
               number(GnssUtils::ssrUpdateIntervalSeconds(message.updateIntervalIndex)), boolText(message.multipleMessage),
               QString::number(message.ssrIod), QString::number(message.providerId), QString::number(message.solutionId),
               QString::number(message.satRefDatum), satelliteText(satellite.sat), QString::number(satellite.iod),
               integerOrEmpty(satellite.toe), boolText(satellite.hasOrbit),
               satellite.hasOrbit ? number(satellite.deltaRadial) : QString(),
               satellite.hasOrbit ? number(satellite.deltaAlongTrack) : QString(),
               satellite.hasOrbit ? number(satellite.deltaCrossTrack) : QString(), boolText(satellite.hasClock),
               satellite.hasClock ? number(satellite.deltaC0) : QString(), boolText(satellite.hasHighRateClock),
               satellite.hasHighRateClock ? number(satellite.highRateClock) : QString(),
               QString::number(satellite.codeBiases.size()), QString::number(satellite.phaseBiases.size()),
               number(age), boolText(adopted), reason});
}

void TelemetryWriter::writeReception(const QString& sourceId,
                                     const QDateTime& receivedUtc,
                                     const QString& messageFamily,
                                     int messageType,
                                     const QChar& system,
                                     const QString& status,
                                     const QString& reason,
                                     const QString& detail) {
    if (!isEnabled()) return;
    appendRow("reception", receivedUtc,
              {sourceId, utcText(receivedUtc), messageFamily, QString::number(messageType),
               QString(system), status, reason, detail});
}

void TelemetryWriter::writePppResiduals(const QString& sourceId, const PppSolution& solution) {
    if (!isEnabled() || !solution.valid || !solution.utc.isValid()) return;
    for (const PppObservationResidual& residual : solution.observationResiduals) {
        appendRow("ppp_residual", solution.utc,
                  {sourceId, utcText(solution.utc), residual.satellite, residual.signal,
                   residual.observationType, number(residual.prefitM),
                   number(residual.postfitM), number(residual.sigmaM),
                   number(residual.elevationDeg), boolText(residual.adopted), residual.reason});
    }
}

void TelemetryWriter::appendRow(const QString& family,
                                const QDateTime& utc,
                                const QStringList& fields) {
    if (!isEnabled()) return;
    FileState* state = fileState(family, utc);
    if (!state) return;

    QStringList escaped;
    escaped.reserve(fields.size());
    for (const QString& field : fields) escaped.push_back(csv(field));
    state->buffer.append(escaped.join(',').toUtf8());
    state->buffer.append('\n');
    constexpr int kFlushThresholdBytes = 64 * 1024;
    if (state->buffer.size() >= kFlushThresholdBytes) {
        flushState(*state);
    }
}

TelemetryWriter::FileState* TelemetryWriter::fileState(const QString& family,
                                                       const QDateTime& utc) {
    const QDateTime dateTime = utc.isValid() ? utc.toUTC() : QDateTime::currentDateTimeUtc();
    const QString date = dateTime.toString("yyyyMMdd");
    const QString key = family + QLatin1Char('|') + date;
    auto existing = _files.find(key);
    if (existing != _files.end()) {
        return &existing.value();
    }

    QDir directory(_directory);
    if (!directory.exists() && !directory.mkpath(".")) return nullptr;
    const QString path = directory.filePath(QString("%1_%2.csv").arg(family, date));
    const QFileInfo info(path);
    const bool writeHeader = !info.exists() || info.size() == 0;

    FileState state;
    state.file = new QFile(path, this);
    if (!state.file->open(QIODevice::WriteOnly | QIODevice::Append)) {
        delete state.file;
        return nullptr;
    }
    if (writeHeader) {
        state.buffer.append(headerFor(family).join(',').toUtf8());
        state.buffer.append('\n');
    }
    auto inserted = _files.insert(key, state);
    return &inserted.value();
}

void TelemetryWriter::flushState(FileState& state) {
    if (!state.file || !state.file->isOpen() || state.buffer.isEmpty()) return;
    while (!state.buffer.isEmpty()) {
        const qint64 written = state.file->write(state.buffer);
        if (written <= 0) {
            break;
        }
        state.buffer.remove(0, static_cast<int>(written));
    }
    state.file->flush();
}

void TelemetryWriter::flush() {
    for (auto it = _files.begin(); it != _files.end(); ++it) {
        flushState(it.value());
    }
}

void TelemetryWriter::close() {
    if (_flushTimer) {
        _flushTimer->stop();
    }
    flush();
    for (auto it = _files.begin(); it != _files.end(); ++it) {
        if (!it.value().file) continue;
        it.value().file->close();
        delete it.value().file;
        it.value().file = nullptr;
    }
    _files.clear();
}

QString TelemetryWriter::csv(const QString& value) {
    QString escaped = value;
    escaped.replace('"', "\"\"");
    return '"' + escaped + '"';
}

QString TelemetryWriter::utcText(const QDateTime& value) {
    return value.isValid() ? value.toUTC().toString(Qt::ISODateWithMs) : QString();
}

QString TelemetryWriter::number(double value) {
    return std::isfinite(value) ? QString::number(value, 'g', 16) : QString();
}

QString TelemetryWriter::integerOrEmpty(int value) {
    return value >= 0 ? QString::number(value) : QString();
}

QString TelemetryWriter::boolText(bool value) { return value ? "true" : "false"; }

QString TelemetryWriter::satelliteText(const RtcmSatId& satellite) {
    if (!satellite.isValid()) return QString();
    return QString("%1%2").arg(satellite.system).arg(satellite.number, 2, 10, QLatin1Char('0'));
}

QString TelemetryWriter::ssrKindText(RtcmSsrCorrectionKind kind) {
    switch (kind) {
    case RtcmSsrCorrectionKind::Orbit: return "orbit";
    case RtcmSsrCorrectionKind::Clock: return "clock";
    case RtcmSsrCorrectionKind::OrbitClock: return "orbit+clock";
    case RtcmSsrCorrectionKind::CodeBias: return "code-bias";
    case RtcmSsrCorrectionKind::PhaseBias: return "phase-bias";
    case RtcmSsrCorrectionKind::HighRateClock: return "high-rate-clock";
    case RtcmSsrCorrectionKind::Ura: return "ura";
    default: return "unknown";
    }
}
