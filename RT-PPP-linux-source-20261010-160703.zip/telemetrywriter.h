#pragma once

#include "ppp_engine.h"
#include "rtcmdecoder.h"

#include <QByteArray>
#include <QDateTime>
#include <QFile>
#include <QMap>
#include <QObject>
#include <QPair>
#include <QString>

class QTimer;

// Appends decoded RTCM and PPP residual telemetry as daily analysis CSV files.
class TelemetryWriter : public QObject
{
public:
    explicit TelemetryWriter(QObject* parent = nullptr);
    ~TelemetryWriter() override;

    void setOutputDirectory(const QString& directory);
    bool isEnabled() const;

    void writeMsm(const QString& sourceId,
                  const QDateTime& receivedUtc,
                  const QDateTime& epochUtc,
                  const RtcmMsmMessage& message,
                  const QMap<QString, QPair<double, double>>& skyBySatellite);
    void writeSsr(const QString& sourceId,
                  const QDateTime& receivedUtc,
                  const QDateTime& epochUtc,
                  const RtcmSsrMessage& message,
                  const RtcmSsrSatelliteData& satellite,
                  bool adopted,
                  const QString& reason);
    void writeReception(const QString& sourceId,
                        const QDateTime& receivedUtc,
                        const QString& messageFamily,
                        int messageType,
                        const QChar& system,
                        const QString& status,
                        const QString& reason,
                        const QString& detail);
    void writePppResiduals(const QString& sourceId, const PppSolution& solution);
    void flush();
    void close();

private:
    struct FileState {
        QFile* file = nullptr;
        QByteArray buffer;
    };

    FileState* fileState(const QString& family, const QDateTime& utc);
    void appendRow(const QString& family, const QDateTime& utc, const QStringList& fields);
    static void flushState(FileState& state);
    static QString csv(const QString& value);
    static QString utcText(const QDateTime& value);
    static QString number(double value);
    static QString integerOrEmpty(int value);
    static QString boolText(bool value);
    static QString satelliteText(const RtcmSatId& satellite);
    static QString ssrKindText(RtcmSsrCorrectionKind kind);

    QString _directory;
    QMap<QString, FileState> _files;
    QTimer* _flushTimer = nullptr;
};
