# BNC BIE 迁移说明

## 目标与边界

- 保留现有 `LAMBDA (MW + NL)` 实现和参数语义。
- 新增独立 `BNC BIE` 后端，通过 GUI 的 `AR algorithm` 下拉框切换。
- BIE 只处理以周表示的 `AMB_L1/AMB_L2` 状态；`AMB_IF` 在当前工程中以米表示，不进入整数搜索。
- BIE 默认只用于生成当前历元固定解副本；固定副本写入 BNC 风格结果日志和 PPP-AR 诊断日志，GUI、JSON、ZTD 与下一历元滤波继续使用浮点参数和协方差。可选的 `Persist BIE constraints to next epoch` 开关打开后，程序按 `系统|频点|卫星` 的连续相位弧确认最近整数候选；达到组内最少稳定数量后，才将本历元 BIE 后验均值和协方差通过矩匹配写回主滤波器。参考星重选和无关可见星变化不会清空已连续的卫星弧；周跳、相位粗差和 SSR 相位偏差不连续只释放受影响卫星。状态转换门限失败时仅保留当历元副本。

## Legacy 对照

| 迁移环节 | BNC legacy | 当前实现 |
| --- | --- | --- |
| 可解筛选 | `AmbRes::isResolvable()` | 历元数、卫星高度角、相位整数指示筛选 |
| 分组 | 系统 + 线性组合 | 系统 + `L1/L2` |
| 参考模糊度 | 最小双差方差和 | 相同准则 |
| 参考约束 | Cholesky + QRZ 平方根 Kalman 联合条件化 | 相同的平方根联合条件化 |
| 整数搜索 | `Lambda::search()` / `BIE()` | LDL、decorrelation、100 候选 search-and-shrink、BIE 加权 |
| 固定筛选 | fractional part + BIE sigma | 相同阈值语义；任一阈值非正表示整体关闭两项筛选 |
| 约束注入 | 所有可固定模糊度，包含参考项 | 相同；任一组满足最少卫星数后统一注入 |
| 状态持久化 | `xFix/QFix` 历元副本，`_xFlt/_QFlt` 不变 | 固定日志生成后立即恢复 `_params/_Q` 浮点副本 |
| 客户端坐标 | `pppFilter::x()` 返回 `_xFlt` | `PppSolution`、GUI 与 JSON 均从恢复后的浮点状态生成 |

对应的 legacy 调用链是：

- `pppFilter.cpp`：复制 `_xFlt/_QFlt` 为 `xFix/QFix`，在副本上执行 `AmbRes::run()`，并用副本调用 `printResult()`。
- `pppFilter.h` 与 `pppClient.cpp`：客户端坐标始终通过 `x()` 读取 `_xFlt`，不会把本历元固定副本作为递推状态或 GUI 坐标。
- `bncutils.cpp`：参考模糊度约束和最终固定约束均通过 Cholesky + QRZ 平方根 Kalman 更新。

## GUI 与配置

`AR algorithm` 提供：

- `LAMBDA (MW + NL)`，配置值 `LAMBDA`。
- `BNC BIE`，配置值 `BNC_BIE`。

BIE 参数保存在 `rtppp_settings.ini` 的 `ppp/arBie*` 项。切换算法会立即重新应用 PPP 设置，并按算法启用对应参数控件。BIE 要求已启用系统使用 `Pi&Li` 或 `P1&L1`；LAMBDA 仍要求 `Pi&Li`。`Persist BIE constraints to next epoch` 默认关闭以保持 BNC 行为；打开后使用逐弧确认历元数、组内稳定数、协方差缩减、U 修正门限和 ZTD 修正门限筛选提交。周跳和相位粗差重置只清除受影响模糊度弧的候选。

## 验证清单

- `ambbie.cpp`、`ppp_engine.cpp`、`mainwindow.cpp` 和 `tests/ambbie_smoke.cpp` 通过 C++17 语法检查。
- `tests/ambbie_smoke.cpp` 覆盖 BNC legacy 自带 12 维 Lambda/BIE golden vector、多组联合固定、参考项约束、不确定结果拒绝和奇异协方差退出。
- `RT-PPP.sln` 的 Debug/Release x64 均已使用 Visual Studio 2022、MSVC v143 和 Qt 5.15.2 `msvc2019_64` 完成编译与链接。
- Visual Studio 主项目显式包含 `ambbie.cpp/ambbie.h`，避免 `BncBie::run()` 出现 `LNK2019/LNK1120`。
